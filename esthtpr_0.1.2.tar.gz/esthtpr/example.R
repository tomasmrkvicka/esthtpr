require(esthtpr)

### Set working directory
# setwd("C:/path/to/directory")


# Specify the observation Window as a list of nonintersecting rectangles
# A1 contains a list of left bottom corners, A2 right bottom corners
# A1,A2,B1,B2 input - type - vectors

A1 = 0; A2 = 500; B1 = 0; B2 = 500;
# A1 = c(0, 1); A2 = c(1, 2); B1 = c(0, 0); B2 = c(1, 0.5);

X1=rThomas(10,0.1,10, win = owin(c(A1[1],A2[1]),c(B1[1],B2[1])))
X2=rThomas(10,0.1,10, win = owin(c(A1[2],A2[2]),c(B1[2],B2[2])))
X=superimpose(X1,X2)
#plot(X)


NStep = 250      # length of MCMC (Recommended at least 50000 for homogeneous Thomas process)
DiscardStep = 50 # discard phase of MCMC (Recommended at least 10000 for homogeneous Thomas process)
PPalpha1 = 2     # shape parameter of the prior distribution for alpha - Gamma distribution
PPalpha2 = 15    # scale parameter of the prior distribution for alpha – Gamma distribution
PPomega1 = 2     # shape parameter of the prior distribution for omega – Gamma distribution
PPomega2 = 0.1   # scale parameter of the prior distribution for omega – Gamma distribution



result = esthtpr(
  A1,
  A2,
  B1,
  B2,
  X,
  NStep = NStep,
  DiscardStep = DiscardStep,
  PPalpha1 = PPalpha1,
  PPalpha2 = PPalpha2,
  PPomega1 = PPomega1,
  PPomega2 = PPomega2,
)

result
