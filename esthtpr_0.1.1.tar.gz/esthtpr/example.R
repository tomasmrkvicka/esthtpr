require(esthtpr)

### Set working directory
# setwd("C:/path/to/directory")


# Specify the observation Window as a list of nonintersecting rectangles
# A1 contains a list of left bottom corners, A2 right bottom corners
# A1,A2,B1,B2 input - type - vectors

A1 = 0; A2 = 500; B1 = 0; B2 = 500;
# A1 = c(0, 1); A2 = c(1, 2); B1 = c(0, 0); B2 = c(1, 0.5);

#settings must be specified
NStep = 250      # length of MCMC (Recommended at least 50000 for homogeneous Thomas process)
DiscardStep = 50 # discard phase of MCMC (Recommended at least 10000 for homogeneous Thomas process)
Jump = 10        # record every Jump step in order to avoid autocorrelation between steps of MCMC
MR = 100         # Maximal range of cluster sizes we expect. Used to simulate extra centers outside of study region
PPalpha1 = 2     # parameters of prior density for alpha - it is Gamma distribution  - shape and scale
PPalpha2 = 15    # PPalha2 is the expected number of points per cluster
PPomega1 = 2     # parameter of prior for omega - it is Gamma distribution  - shape and scale
PPomega2 = 100   # PPomega2 is the expected radii of the cluster
salpha = PPalpha2 / 30  # standard deviation for update of alpha
somega = PPomega2 / 30  # standard deviation for update of omega
Silent = FALSE    # If the program should print the results during the run



result = esthtpr(
  A1,               # Specify the observation Window as a list of nonintersecting rectangles
  A2,               # A1 contains a list of left bottom corners, A2 right bottom corners
  B1,
  B2,
  NStep = NStep,      # length of MCMC (Recommended at least 50000 for homogeneous Thomas process)
  DiscardStep = DiscardStep, # discard phase of MCMC (Recommended at least 10000 for homogeneous Thomas process)
  Jump = Jump,        # record every Jump step in order to avoid autocorrelation between steps of MCMC
  MR = MR,         # Maximal range of cluster sizes we expect. Used to simulate extra centers outside of study region
  PPalpha1 = PPalpha1,     # parameters of prior density for alpha - it is Gamma distribution  - shape and scale
  PPalpha2 = PPalpha2,    # PPalha2 is the expected number of points per cluster
  PPomega1 = PPomega1,     # parameter of prior for omega - it is Gamma distribution  - shape and scale
  PPomega2 = PPomega2,   # PPomega2 is the expected radii of the cluster
  salpha = salpha,  # standard deviation for update of alpha
  somega = somega,  # standard deviation for update of omega
  Silent = Silent    # If the program should print the results during the run
)

result
