#' esthtpr estimation of homogeneous Thomas process.
#'
#' MCMC estimate of parameters in homogeneous Thomas process.
#'
#' @docType package
#' @name esthtpr
#' @description This function performs the Bayesian MCMC estimation
#'      of parameters in homogeneous Thomas process.
#'      The process is set in observation window W which is
#'      a union of rectangles.
#'
#' @author Tomas Mrkvicka <mrkvicka.toma@gmail.com> (author), Ladislav Beranek <beranek@jcu.cz> (maintainer), Radim Remes <inrem@jcu.cz> (maintainer)
#'
#' @import spatstat mvtnorm stats
#' @note
#'     License: GPL-3
#'
#'     Encoding: UTF-8
#'
NULL
