* example.R 
	Runs a MCMC estimation in homogeneous Thomas process for a simulated pattern (i.e. does it all).

* R/esthtpr.R
	The actual execution of the MCMC estimation.
